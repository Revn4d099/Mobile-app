import 'package:flutter/material.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanloginwidget/GeneratedHALAMANLOGINWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedmapelwidget/GeneratedMAPELWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedmapelwidget1/GeneratedMAPELWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/GeneratedHalamanawalWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatednamamapelwidget2/GeneratedNamaMapelWidget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedtingkatpendidikanwidget/GeneratedTingkatpendidikanWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedjawabwidget/GeneratedJawabWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamandaftarwidget/GeneratedHALAMANDAFTARWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanmasukwidget/GeneratedHALAMANMASUKWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedajukanpertanyaanwidget/GeneratedAJUKANPERTANYAANWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedpertanyaanwidget/GeneratedPertanyaanWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedjawabwidget16/GeneratedJAWABWidget16.dart';
import 'package:flutterapp/app_20mobileapp/generatedmainmenuwidget/GeneratedMAINMENUWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedscrolltampilanawalwidget/GeneratedSCROLLTAMPILANAWALWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedkomunitasorangtuawidget/GeneratedKOMUNITASORANGTUAWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedkomunitassekolahguruwidget/GeneratedKOMUNITASSEKOLAHGURUWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedkomunitaswidget/GeneratedKOMUNITASWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedguestwidget/GeneratedGUESTWidget.dart';
import 'package:flutterapp/app_20mobileapp/generateduserwidget/GeneratedUSERWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedadminwidget/GeneratedADMINWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedprofilwidget/GeneratedPROFILWidget.dart';
import 'package:flutterapp/app_20mobileapp/generateddashboardadminwidget/GeneratedDASHBOARDADMINWidget.dart';
import 'package:flutterapp/app_20mobileapp/generateddashboardadminsampingwidget/GeneratedDASHBOARDADMINSAMPINGWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedbreakwidget1/GeneratedBreakWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatediconpluswidget/GeneratediconplusWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatediconheartoutlinewidget/GeneratediconheartoutlineWidget.dart';
import 'package:flutterapp/app_20mobileapp/generatedimage26widget/GeneratedImage26Widget.dart';

void main() {
  runApp(app_20mobileApp());
}

class app_20mobileApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedHALAMANLOGINWidget',
      routes: {
        '/GeneratedHALAMANLOGINWidget': (context) =>
            GeneratedHALAMANLOGINWidget(),
        '/GeneratedMAPELWidget': (context) => GeneratedMAPELWidget(),
        '/GeneratedMAPELWidget1': (context) => GeneratedMAPELWidget1(),
        '/GeneratedHalamanawalWidget': (context) =>
            GeneratedHalamanawalWidget(),
        '/GeneratedNamaMapelWidget2': (context) => GeneratedNamaMapelWidget2(),
        '/GeneratedTingkatpendidikanWidget': (context) =>
            GeneratedTingkatpendidikanWidget(),
        '/GeneratedJawabWidget': (context) => GeneratedJawabWidget(),
        '/GeneratedHALAMANDAFTARWidget': (context) =>
            GeneratedHALAMANDAFTARWidget(),
        '/GeneratedHALAMANMASUKWidget': (context) =>
            GeneratedHALAMANMASUKWidget(),
        '/GeneratedAJUKANPERTANYAANWidget': (context) =>
            GeneratedAJUKANPERTANYAANWidget(),
        '/GeneratedPertanyaanWidget': (context) => GeneratedPertanyaanWidget(),
        '/GeneratedJAWABWidget16': (context) => GeneratedJAWABWidget16(),
        '/GeneratedMAINMENUWidget': (context) => GeneratedMAINMENUWidget(),
        '/GeneratedSCROLLTAMPILANAWALWidget': (context) =>
            GeneratedSCROLLTAMPILANAWALWidget(),
        '/GeneratedKOMUNITASORANGTUAWidget': (context) =>
            GeneratedKOMUNITASORANGTUAWidget(),
        '/GeneratedKOMUNITASSEKOLAHGURUWidget': (context) =>
            GeneratedKOMUNITASSEKOLAHGURUWidget(),
        '/GeneratedKOMUNITASWidget': (context) => GeneratedKOMUNITASWidget(),
        '/GeneratedGUESTWidget': (context) => GeneratedGUESTWidget(),
        '/GeneratedUSERWidget': (context) => GeneratedUSERWidget(),
        '/GeneratedADMINWidget': (context) => GeneratedADMINWidget(),
        '/GeneratedPROFILWidget': (context) => GeneratedPROFILWidget(),
        '/GeneratedDASHBOARDADMINWidget': (context) =>
            GeneratedDASHBOARDADMINWidget(),
        '/GeneratedDASHBOARDADMINSAMPINGWidget': (context) =>
            GeneratedDASHBOARDADMINSAMPINGWidget(),
        '/GeneratedBreakWidget1': (context) => GeneratedBreakWidget1(),
        '/GeneratediconplusWidget': (context) => GeneratediconplusWidget(),
        '/GeneratediconheartoutlineWidget': (context) =>
            GeneratediconheartoutlineWidget(),
        '/GeneratedImage26Widget': (context) => GeneratedImage26Widget(),
      },
    );
  }
}
