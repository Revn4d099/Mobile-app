import 'package:flutter/material.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedMAPELWidget3.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedJAWABWidget7.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratediconarrowleftWidget3.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage1Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedLine11Widget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/Generated2menityanglaluWidget4.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedWidget5.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget19.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratediconarrowleftWidget4.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedJAWABWidget6.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedParagrafinduktifadalahjenisparagrafyangberkebalikandari2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedCariWidget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/Generated5Widget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget17.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedHasilnyaadalahduaperlimakakWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedGroup23Widget.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedJAWABWidget9.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedGroup22Widget.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratediconarrowleftWidget5.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage2Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedKodeEtikWidget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget20.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget16.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedRectangle31Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget14.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedLine14Widget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedGroup26Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedRectangle48Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage4Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedJAWABWidget8.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget15.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedMatematikaWidget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratediconsearchoutlineWidget3.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedGroup250Widget.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage5Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedNamaMapelWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/Generated5Widget3.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedUntukOrangTuaWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage3Widget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedUntukGuruWidget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedMATEMATIKAWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedImage6Widget2.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedPERTANYAANBARUWidget1.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget18.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedTEKSTOMBOLPERTANYAANWidget13.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/Generated2menityanglaluWidget5.dart';
import 'package:flutterapp/app_20mobileapp/generatedhalamanawalwidget/generated/GeneratedWidget4.dart';

/* Frame halaman awal
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedHalamanawalWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.zero,
      child: Container(
        width: 360.0,
        height: 640.0,
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.zero,
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              Positioned(
                left: 280.0,
                top: 445.0,
                right: null,
                bottom: null,
                width: 47.400001525878906,
                height: 15.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget13(),
              ),
              Positioned(
                left: 280.0,
                top: 588.0,
                right: null,
                bottom: null,
                width: 47.400001525878906,
                height: 15.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget14(),
              ),
              Positioned(
                left: 60.0,
                top: 141.0,
                right: null,
                bottom: null,
                width: 255.0,
                height: 24.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget15(),
              ),
              Positioned(
                left: 59.0,
                top: 232.0,
                right: null,
                bottom: null,
                width: 255.0,
                height: 24.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget16(),
              ),
              Positioned(
                left: 60.0,
                top: 292.0,
                right: null,
                bottom: null,
                width: 255.0,
                height: 18.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget17(),
              ),
              Positioned(
                left: 296.0,
                top: 334.0,
                right: null,
                bottom: null,
                width: 29.0,
                height: 9.293174743652344,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget18(),
              ),
              Positioned(
                left: 296.0,
                top: 496.0,
                right: null,
                bottom: null,
                width: 25.399988174438477,
                height: 10.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget19(),
              ),
              Positioned(
                left: 103.0,
                top: 19.0,
                right: null,
                bottom: null,
                width: 193.0,
                height: 24.0,
                child: GeneratedTEKSTOMBOLPERTANYAANWidget20(),
              ),
              Positioned(
                left: 0.0,
                top: 74.0,
                right: null,
                bottom: null,
                width: 360.0,
                height: 1.0,
                child: GeneratedLine11Widget2(),
              ),
              Positioned(
                left: 0.0,
                top: 476.0,
                right: null,
                bottom: null,
                width: 360.5,
                height: 0.0,
                child: GeneratedLine14Widget2(),
              ),
              Positioned(
                left: 81.0,
                top: 148.0,
                right: null,
                bottom: null,
                width: 65.0,
                height: 15.0,
                child: GeneratedMAPELWidget3(),
              ),
              Positioned(
                left: 15.0,
                top: 56.0,
                right: null,
                bottom: null,
                width: 80.0,
                height: 12.0,
                child: GeneratedUntukOrangTuaWidget1(),
              ),
              Positioned(
                left: 140.0,
                top: 56.0,
                right: null,
                bottom: null,
                width: 80.0,
                height: 12.0,
                child: GeneratedUntukGuruWidget2(),
              ),
              Positioned(
                left: 265.0,
                top: 56.0,
                right: null,
                bottom: null,
                width: 80.0,
                height: 12.0,
                child: GeneratedKodeEtikWidget2(),
              ),
              Positioned(
                left: 341.0,
                top: 48.0,
                right: null,
                bottom: null,
                width: 20.0,
                height: 32.0,
                child: GeneratedRectangle31Widget1(),
              ),
              Positioned(
                left: 120.0,
                top: 26.0,
                right: null,
                bottom: null,
                width: 65.0,
                height: 15.0,
                child: GeneratedCariWidget2(),
              ),
              Positioned(
                left: 60.0,
                top: 187.0,
                right: null,
                bottom: null,
                width: 255.0,
                height: 24.0,
                child: GeneratedGroup26Widget1(),
              ),
              Positioned(
                left: 75.0,
                top: 238.0,
                right: null,
                bottom: null,
                width: 112.0,
                height: 15.0,
                child: GeneratedJAWABWidget6(),
              ),
              Positioned(
                left: 85.0,
                top: 334.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 15.0,
                child: GeneratedMATEMATIKAWidget1(),
              ),
              Positioned(
                left: 88.0,
                top: 494.0,
                right: null,
                bottom: null,
                width: 59.0,
                height: 12.0,
                child: GeneratedMatematikaWidget2(),
              ),
              Positioned(
                left: 287.0,
                top: 446.0,
                right: null,
                bottom: null,
                width: 62.0,
                height: 15.0,
                child: GeneratedJAWABWidget7(),
              ),
              Positioned(
                left: 289.0,
                top: 590.0,
                right: null,
                bottom: null,
                width: 62.0,
                height: 15.0,
                child: GeneratedJAWABWidget8(),
              ),
              Positioned(
                left: 289.0,
                top: 590.0,
                right: null,
                bottom: null,
                width: 62.0,
                height: 15.0,
                child: GeneratedJAWABWidget9(),
              ),
              Positioned(
                left: 51.0,
                top: 373.0,
                right: null,
                bottom: null,
                width: 150.0,
                height: 12.0,
                child: GeneratedHasilnyaadalahduaperlimakakWidget1(),
              ),
              Positioned(
                left: 51.0,
                top: 538.0,
                right: null,
                bottom: null,
                width: 238.0,
                height: 12.0,
                child:
                    GeneratedParagrafinduktifadalahjenisparagrafyangberkebalikandari2(),
              ),
              Positioned(
                left: 155.0,
                top: 333.0,
                right: null,
                bottom: null,
                width: 83.0,
                height: 12.0,
                child: Generated2menityanglaluWidget4(),
              ),
              Positioned(
                left: 155.0,
                top: 494.0,
                right: null,
                bottom: null,
                width: 83.0,
                height: 12.0,
                child: Generated2menityanglaluWidget5(),
              ),
              Positioned(
                left: 147.0,
                top: 330.0,
                right: null,
                bottom: null,
                width: 17.0,
                height: 15.0,
                child: GeneratedWidget4(),
              ),
              Positioned(
                left: 147.0,
                top: 491.0,
                right: null,
                bottom: null,
                width: 17.0,
                height: 15.0,
                child: GeneratedWidget5(),
              ),
              Positioned(
                left: 141.0,
                top: 296.0,
                right: null,
                bottom: null,
                width: 109.0,
                height: 12.0,
                child: GeneratedPERTANYAANBARUWidget1(),
              ),
              Positioned(
                left: 15.0,
                top: 69.0,
                right: null,
                bottom: null,
                width: 190.0,
                height: 3.0,
                child: GeneratedRectangle48Widget1(),
              ),
              Positioned(
                left: 51.0,
                top: 323.0,
                right: null,
                bottom: null,
                width: 30.0,
                height: 29.0,
                child: GeneratedImage3Widget1(),
              ),
              Positioned(
                left: 311.0,
                top: 335.0,
                right: null,
                bottom: null,
                width: 21.0,
                height: 7.0,
                child: Generated5Widget2(),
              ),
              Positioned(
                left: 311.0,
                top: 498.0,
                right: null,
                bottom: null,
                width: 21.0,
                height: 7.0,
                child: Generated5Widget3(),
              ),
              Positioned(
                left: 47.0,
                top: 484.0,
                right: null,
                bottom: null,
                width: 26.0,
                height: 26.0,
                child: GeneratedImage6Widget2(),
              ),
              Positioned(
                left: 804.0,
                top: 202.0,
                right: null,
                bottom: null,
                width: 62.0,
                height: 12.0,
                child: GeneratedNamaMapelWidget1(),
              ),
              Positioned(
                left: 283.0,
                top: 164.599853515625,
                right: null,
                bottom: null,
                width: 21.602195739746094,
                height: 21.602195739746094,
                child: GeneratediconarrowleftWidget3(),
              ),
              Positioned(
                left: 283.0,
                top: 209.599853515625,
                right: null,
                bottom: null,
                width: 21.602195739746094,
                height: 21.602195739746094,
                child: GeneratediconarrowleftWidget4(),
              ),
              Positioned(
                left: 283.0,
                top: 254.599853515625,
                right: null,
                bottom: null,
                width: 21.602195739746094,
                height: 21.602195739746094,
                child: GeneratediconarrowleftWidget5(),
              ),
              Positioned(
                left: 270.0,
                top: 24.0,
                right: null,
                bottom: null,
                width: 15.234771728515625,
                height: 15.234771728515625,
                child: GeneratediconsearchoutlineWidget3(),
              ),
              Positioned(
                left: 309.0,
                top: 14.0,
                right: null,
                bottom: null,
                width: 36.0,
                height: 36.0,
                child: GeneratedImage2Widget1(),
              ),
              Positioned(
                left: 300.0,
                top: 335.0,
                right: null,
                bottom: null,
                width: 7.0,
                height: 7.0,
                child: GeneratedImage4Widget1(),
              ),
              Positioned(
                left: 300.0,
                top: 498.0,
                right: null,
                bottom: null,
                width: 7.0,
                height: 7.0,
                child: GeneratedImage5Widget1(),
              ),
              Positioned(
                left: 12.0,
                top: 18.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 32.0,
                child: GeneratedImage1Widget1(),
              ),
              Positioned(
                left: 47.0,
                top: 442.0,
                right: null,
                bottom: null,
                width: 148.0,
                height: 18.0,
                child: GeneratedGroup22Widget(),
              ),
              Positioned(
                left: 250.0,
                top: 2.0,
                right: null,
                bottom: null,
                width: 101.0,
                height: 12.283783912658691,
                child: GeneratedGroup250Widget(),
              ),
              Positioned(
                left: 12.0,
                top: 3.0,
                right: null,
                bottom: null,
                width: 84.0,
                height: 18.0,
                child: GeneratedGroup23Widget(),
              )
            ]),
      ),
    ));
  }
}
